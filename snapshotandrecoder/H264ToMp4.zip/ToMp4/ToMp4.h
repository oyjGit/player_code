#ifdef TOMP4_EXPORTS
#define TOMP4_API __declspec(dllexport)
#else
#define TOMP4_API __declspec(dllimport)
#endif

extern "C" TOMP4_API int  __stdcall fnGetObject(char *pMp4FileName);

extern "C" TOMP4_API int  __stdcall fnInputVideoData(char *pData, int iDataLen);

extern "C" TOMP4_API int  __stdcall fnInputAudioData(char *pData, int iDataLen);

extern "C" TOMP4_API int  __stdcall fnFreeObject();



