// ToMp4.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "ToMp4.h"
#include "mp4encoder.h"

MP4Encoder *g_pMp4 = NULL;

TOMP4_API int  __stdcall fnGetObject(char *pMp4FileName)
{
	if (g_pMp4 == NULL) g_pMp4 = new MP4Encoder();

	g_pMp4->CreateMP4File(pMp4FileName,352,288);


	return 0;
}

TOMP4_API int  __stdcall fnInputVideoData(char *pData, int iDataLen)
{
	if (g_pMp4 == NULL) return -1;


	return g_pMp4->WriteH264Data((unsigned char *)pData,iDataLen,0);
}

TOMP4_API int  __stdcall fnInputAudioData(char *pData, int iDataLen)
{
	if (g_pMp4 == NULL) return -1;
	return g_pMp4->WriteULawData((unsigned char *)pData,iDataLen,0);

	return 0;
}

TOMP4_API int  __stdcall fnFreeObject()
{
	if (g_pMp4 == NULL) return -1;

	g_pMp4->CloseMP4File();
	delete g_pMp4;
	g_pMp4 = NULL;
	return 0;
}