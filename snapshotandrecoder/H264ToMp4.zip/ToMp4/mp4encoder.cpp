/********************************************************************
filename:   MP4Encoder.cpp
created:    2013-04-16
author:     firehood
purpose:    MP4编码器，基于开源库mp4v2实现（https://code.google.com/p/mp4v2/）。
*********************************************************************/

#include "StdAfx.h"
#include "mp4encoder.h"

#include <string.h>

#include "mp4v2/mp4v2.h"

#define BUFFER_SIZE  (1024*1024)
#define AUDIO_TIME_SCALE 8000
#define VIDEO_TIME_SCALE 90000
#define PTS2TIME_SCALE(CurPTS, PrevPTS, timeScale) \
((MP4Duration)((CurPTS - PrevPTS) * 1.0 / (double)(1e+6) * timeScale))


#define INVALID_PTS 0xFFFFFFFFFFFFFFFF

MP4Encoder::MP4Encoder():
    m_videoId(NULL),
    m_nWidth(0),
    m_nHeight(0),
    m_nTimeScale(0),
    m_nFrameRate(0),
    m_audioId(NULL),
	m_u64VideoPTS(0),
	m_u64AudioPTS(0),
	m_u64FirstPTS(INVALID_PTS),
	m_u64LastPTS(INVALID_PTS),
	m_bFirstAudio(TRUE),
	m_bFirstVideo(TRUE)
{
}

MP4Encoder::~MP4Encoder()
{

}

bool MP4Encoder::CreateMP4File(const char *pFileName,int width,int height,
                                        int timeScale/* = 90000*/,int frameRate/* = 25*/)
{
    if(pFileName == NULL)
    {
        return false;
    }
    // create mp4 file
    hMp4File = MP4Create(pFileName);
    if (hMp4File == MP4_INVALID_FILE_HANDLE)
    {
        printf("ERROR:Open file fialed.\n");
        return false;
    }
    m_nWidth = width;
    m_nHeight = height;
    m_nTimeScale = timeScale;
    m_nFrameRate = frameRate;
    MP4SetTimeScale(hMp4File, m_nTimeScale);
    return true;
}


int MP4Encoder::WriteH264Data(const unsigned char* pData, int size,int u64PTS)
{
    if(hMp4File == NULL || pData == NULL)
    {
        return -1;
    }

    MP4ENC_NaluUnit nalu;
    int pos = 0, len = 0;
    while (len = ReadOneNaluFromBuf(pData,size,pos,nalu))
    {

        if(nalu.type == 0x07) // sps
        {
            // 添加h264 track
            if(m_videoId == NULL){
                m_videoId = MP4AddH264VideoTrack
                    (hMp4File,
                    m_nTimeScale,
                    m_nTimeScale / m_nFrameRate,
                    m_nWidth,     // width
                    m_nHeight,    // height
                    nalu.data[1], // sps[1] AVCProfileIndication
                    nalu.data[2], // sps[2] profile_compat
                    nalu.data[3], // sps[3] AVCLevelIndication
                    3);           // 4 bytes length before each NAL unit
                if (m_videoId == MP4_INVALID_TRACK_ID)
                {
                    printf("add video track failed.\n");
                    return 0;
                }
                MP4SetVideoProfileLevel(hMp4File, 0x7F); //  Simple Profile @ Level 3
                MP4AddH264SequenceParameterSet(hMp4File,m_videoId,nalu.data,nalu.size);
            }
        }
        else if(nalu.type == 0x08) // pps
        {
            MP4AddH264PictureParameterSet(hMp4File,m_videoId,nalu.data,nalu.size);
        }
        else
        {
            if(m_videoId == NULL){
                return 0;
            }
            bool isKeyFrame = (nalu.type == 0x05);
            int datalen = nalu.size+4;
            unsigned char *data = new unsigned char[datalen];
            // MP4 Nalu前四个字节表示Nalu长度
            data[0] = nalu.size>>24;
            data[1] = nalu.size>>16;
            data[2] = nalu.size>>8;
            data[3] = nalu.size&0xff;
            memcpy(data+4,nalu.data,nalu.size);


			if (m_bFirstVideo)
			{
				if (m_u64FirstPTS > u64PTS)
					m_u64FirstPTS = u64PTS;
				m_u64VideoPTS = u64PTS;
				m_bFirstVideo = FALSE;
			}
		//	int iSecs = PTS2TIME_SCALE(u64PTS, m_u64VideoPTS, VIDEO_TIME_SCALE);

			//TRACE("iSecs=%d,u64PTS=%d\n",iSecs,u64PTS);

            //if(!MP4WriteSample(hMp4File, m_videoId, data, datalen, timeScale(VIDEO_TIME_SCALE)/25, 0, isKeyFrame))
			if(!MP4WriteSample(hMp4File, m_videoId, data, datalen,MP4_INVALID_DURATION , 0, isKeyFrame))
            {
                delete[] data;
                return 0;
            }
            delete[] data;

			m_u64LastPTS = m_u64VideoPTS = u64PTS;
        }

        pos += len;
    }
    return pos;
}
int MP4Encoder::WriteULawData(const unsigned char *pData, int size, int u64PTS)
{
    if(hMp4File == NULL || pData == NULL)
    {
        return -1;
    }
    if(m_audioId == NULL){

        m_audioId = MP4AddULawAudioTrack(hMp4File, 8000);
        if(m_audioId == MP4_INVALID_TRACK_ID)
        {
            return 0;
        }

//        MP4SetTrackESConf   iguration();
//        MP4SetTrackESConfiguration(fileHandle, audio, &ubuffer[0], 2);
        //this is important
        bool  a = MP4SetTrackIntegerProperty( hMp4File,  m_audioId,
                                             "mdia.minf.stbl.stsd.ulaw.channels", 1);  //Set a single audio channel

        MP4SetAudioProfileLevel(hMp4File, 0x02);


    }else{

/*
bool MP4WriteSample(
MP4FileHandle  hFile,
MP4TrackId     trackId,
const uint8_t* pBytes,
uint32_t       numBytes,
MP4Duration    duration DEFAULT(MP4_INVALID_DURATION),
MP4Duration    renderingOffset DEFAULT(0),
    bool           isSyncSample DEFAULT(true));		
*/
		if (m_bFirstAudio)
		{
			if (m_u64FirstPTS > u64PTS)
				m_u64FirstPTS = u64PTS;
			m_u64AudioPTS = u64PTS;
			m_bFirstAudio = FALSE;
		}

//         if(!MP4WriteSample(hMp4File, m_audioId, pData, size,PTS2TIME_SCALE(u64PTS, m_u64AudioPTS, AUDIO_TIME_SCALE)))
//         {
//             return 0;
//         }
        if(!MP4WriteSample(hMp4File, m_audioId, pData, size))
        {
            return 0;
        }

    }
    return size;
}

int MP4Encoder::ReadOneNaluFromBuf(const unsigned char *buffer,unsigned int nBufferSize,unsigned int offSet,MP4ENC_NaluUnit &nalu)
{
    int i = offSet;
    while(i<nBufferSize)
    {
        if(buffer[i++] == 0x00 &&
            buffer[i++] == 0x00 &&
            buffer[i++] == 0x00 &&
            buffer[i++] == 0x01
            )
        {
            int pos = i;
            while (pos<nBufferSize)
            {
                if(buffer[pos++] == 0x00 &&
                    buffer[pos++] == 0x00 &&
                    buffer[pos++] == 0x00 &&
                    buffer[pos++] == 0x01
                    )
                {
                    break;
                }
            }
            if(pos == nBufferSize)
            {
                nalu.size = pos-i;
            }
            else
            {
                nalu.size = (pos-4)-i;
            }

            nalu.type = buffer[i]&0x1f;
            nalu.data =(unsigned char*)&buffer[i];
            return (nalu.size+i-offSet);
        }
    }
    return 0;
}

void MP4Encoder::CloseMP4File()
{
    if(hMp4File)
    {
        MP4Close(hMp4File);
        hMp4File = NULL;
        m_videoId = NULL;
        m_audioId = NULL;
    }
}


bool MP4Encoder:: PraseMetadata(const unsigned char* pData,int size,MP4ENC_Metadata &metadata)
{
    if(pData == NULL || size<4)
    {
        return false;
    }
    MP4ENC_NaluUnit nalu;
    int pos = 0;
    bool bRet1 = false,bRet2 = false;
    while (int len = ReadOneNaluFromBuf(pData,size,pos,nalu))
    {
        if(nalu.type == 0x07)
        {
            memcpy(metadata.Sps,nalu.data,nalu.size);
            metadata.nSpsLen = nalu.size;
            bRet1 = true;
        }
        else if((nalu.type == 0x08))
        {
            memcpy(metadata.Pps,nalu.data,nalu.size);
            metadata.nPpsLen = nalu.size;
            bRet2 = true;
        }
        pos += len;
    }
    if(bRet1 && bRet2)
    {
        return true;
    }
    return false;
}

